import { Component, OnInit } from '@angular/core';
// import * as N3 from '../../node_modules/n3/N3.js';

declare var ol: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  latitude = 40.423533061444374;
  longitude = -3.7045899778604507;

  map: any;

  ngOnInit() {

    /*const parser = new N3.Parser();
    parser.parse(
      `PREFIX c: <http://example.org/cartoons#>
   c:Tom a c:Cat.
   c:Jerry a c:Mouse;
           c:smarterThan c:Tom.`,
      (error, quad, prefixes) => {
        if (quad) {
          console.log(quad);
        } else {
          console.log('# That\'s all, folks!', prefixes);
        }
      });*/

    this.map = new ol.Map({
      target: 'map',
      controls: ol.control.defaults({
        attributionOptions: {
          collapsible: false
        }
      })/*.extend([mousePositionControl])*/,
      layers: [
        new ol.layer.Tile({
          source: new ol.source.OSM()
        })
      ],
      view: new ol.View({
        center: ol.proj.fromLonLat([-3.7045899778604507, 40.423533061444374]),
        zoom: 13
      })
    });


    // ADD A MARKER
    // SPARQL query para obtener todos los Parking, recorrer el resultado uno a uno
    // haciendo SPARQL query para sacar la longitud y la latitud
    const markers = [
      {
        lat: 40.426687899755734, lng: -3.6996173701222492, nombre: 'Aparcamiento mixto. Arquitecto Ribera',
        horario: 'Abierto 24 horas', publicas: 318, residentes: 298, telefono: 'sn',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43d' +
          'b40317010VgnVCM100000dc0ca8c0RCRD&vgnextoid=a50e15cbed51c010VgnVCM2000000c205a0aRCRD'
      },
      {
        lat: 40.43886083125741, lng: -3.6766217383743345, nombre: 'Aparcamiento mixto. Avenida de América (intercambiador)',
        horario: 'Abierto 24 horas', publicas: 269, residentes: 392, telefono: '917 376 257',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43db' +
          '40317010VgnVCM100000dc0ca8c0RCRD&vgnextoid=3f3bc2c6e051c010VgnVCM2000000c205a0aRCRD'
      },
      {
        lat: 40.411180021966345, lng: -3.7378318857463158, nombre: 'Aparcamiento mixto. Avenida de Portugal',
        horario: 'Horario de apertura de 6:00 h a 22:00 h los días laborables.', publicas: 432, residentes: 437, telefono: '917 877 292',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43db4031' +
          '7010VgnVCM100000dc0ca8c0RCRD&vgnextoid=c313e26f2b3fc210VgnVCM2000000c205a0aRCRD'
      },
      {
        lat: 40.45610834965894, lng: -3.694131675088486, nombre: 'Aparcamiento mixto. Brasil',
        horario: 'Abierto 24 horas', publicas: 226, residentes: 400, telefono: 'sn',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43db4031701' +
          '0VgnVCM100000dc0ca8c0RCRD&vgnextoid=fb2e15cbed51c010VgnVCM2000000c205a0aRCRD'
      },
      {
        lat: 40.406792648617134, lng: -3.7046086019457167, nombre: 'Aparcamiento mixto. Casino de la Reina',
        horario: 'Abierto 24 horas', publicas: 135, residentes: 449, telefono: 'sn',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43db40317010VgnV' +
          'CM100000dc0ca8c0RCRD&vgnextoid=c5f4bdc85c01c010VgnVCM2000000c205a0aRCRD'
      },
      {
        lat: 40.44938567948415, lng: -3.7019164121880888, nombre: 'Aparcamiento mixto. Condesa de Gavia',
        horario: 'Abierto 24 horas', publicas: 73, residentes: 79, telefono: 'sn',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43db40317010VgnV' +
          'M100000dc0ca8c0RCRD&vgnextoid=7e5f15cbed51c010VgnVCM2000000c205a0aRCRD'
      },
      {
        lat: 40.444421820483264, lng: -3.666902094780133, nombre: 'Aparcamiento mixto. Corazón de María II',
        horario: 'Abierto 24 horas', publicas: 327, residentes: 750, telefono: '915 563 165',
        url: 'http://www.madrid.es/sites/v/index.jsp?vgnextchannel=9e4c43db40317010VgnVCM100' +
          '000dc0ca8c0RCRD&vgnextoid=b74e6545f951c010VgnVCM2000000c205a0aRCRD'
      }
    ];
    const features = [];

    for (let i = 0; i < markers.length; i++) {
      const m = markers[i];
      const longitude = m.lng;
      const latitude = m.lat;

      const iconFeature = new ol.Feature({
        geometry: new ol.geom.Point(ol.proj.transform([longitude, latitude], 'EPSG:4326', 'EPSG:3857')),
        description: '<h3><a href=\'' + m.url + '\'>' + m.nombre + '</a></h3>' +
          m.horario + '<br>Plazas publicas: ' + m.publicas +
          '<br>Plazas residentes: ' + m.residentes +
          '<br>Teléfono: ' + m.telefono
      });

      const iconStyle = new ol.style.Style({
        image: new ol.style.Icon(({
          anchor: [0.5, 1],
          src: 'http://cdn.mapmarker.io/api/v1/pin?text=P&size=40&hoffset=1'
        }))
      });

      iconFeature.setStyle(iconStyle);
      features.push(iconFeature);

    }

    const container = document.getElementById('ol-popup');
    const content = document.getElementById('ol-popup-content');
    const closer = document.getElementById('ol-popup-closer');


    const popup = new ol.Overlay({
      element: container,
      autoPan: true,
      positioning: 'bottom-center',
      stopEvent: false,
      offset: [0, -5]
    });

    closer.onclick = function () {
      popup.setPosition(undefined);
      closer.blur();
      return false;
    };
    this.map.addOverlay(popup);

    this.map.on('click', (evt) => {
      const feature = this.map.forEachFeatureAtPixel(evt.pixel, (feat) => {
        return feat;
      });
      if (feature) {
        const coordinate = evt.coordinate;
        content.innerHTML = feature.get('description');
        popup.setPosition(coordinate);
      }


    });

    const vectorSource = new ol.source.Vector({
      features: features
    });

    const markerVectorLayer = new ol.layer.Vector({
      source: vectorSource,
    });

    this.map.addLayer(markerVectorLayer);

  }

  setCenter() {
    const view = this.map.getView();
    view.setCenter(ol.proj.fromLonLat([this.longitude, this.latitude]));
    view.setZoom(13);
  }
}
