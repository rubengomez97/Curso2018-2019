# apliacionWeb



Para configurar los host virtuales, anadir al archivo httpd.conf de apache:

hay que poner las rutas que correspondan, esas son las locales de mi portatil

<VirtualHost *:80>
    ServerName callejero.api.local
    ServerAlias callejero.api.local

    DocumentRoot C:\Users\Jaime\Desktop\webSemantica\callejero-api\public
    <Directory C:\Users\Jaime\Desktop\webSemantica\callejero-api\public>
        AllowOverride None
        Order Allow,Deny
        Allow from All

        FallbackResource /index.php
    </Directory>
</VirtualHost>


y al final del archivo C:\Windows\System32\drivers\etc\hosts :


	127.0.0.1	callejero.api.local
	127.0.0.1	callejero.app.local



aceder a la API via postman o con el navegador con las rutas:



 -------------------- -------- -------- ------ --------------------------
  Name                 Method   Scheme   Host   Path                     
 -------------------- -------- -------- ------ --------------------------
  barriosRoute         GET      ANY      ANY    callejero.api.local/barrios
  barioInfoRoute       GET      ANY      ANY    callejero.api.local/barrios/{idBarrio}
  direccionesRoute     GET      ANY      ANY    callejero.api.local/direcciones
  direccionInfoRoute   GET      ANY      ANY    callejero.api.local/direccion/{idDireccion}
  distritosRoute       GET      ANY      ANY    callejero.api.local/distritos
  distritoRoute        GET      ANY      ANY    callejero.api.local/distritos/{idDistrito}
 -------------------- -------- -------- ------ --------------------------
