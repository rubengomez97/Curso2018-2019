<?php
/**
 * Created by PhpStorm.
 * User: Jaime
 * Date: 02/12/2018
 * Time: 17:39
 */

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Service\Calles;


class CallesAPI
{


    /**
     * @Route("/calles",
     *     name="callesRoute",
     *     methods={"GET"}
     *     )
     */

    public function getAllCalles()
    {

        $content = Calles::getCalles();
        $response = new Response( json_encode($content),
            Response::HTTP_OK,
            array('content-type' => 'application/json')
        );

        $response->headers->set('Access-Control-Allow-Origin', '*');
        return $response;
    }
}