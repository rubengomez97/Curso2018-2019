<?php
/**
 * Created by PhpStorm.
 * User: Jaime
 * Date: 14/12/2018
 * Time: 14:40
 */

namespace App\Service;

use BorderCloud\SPARQL\SparqlClient;
use Symfony\Component\Config\Definition\Exception\Exception;

class Portales
{

    public static function getPortales()
    {
        $endpoint = "http://datos.zaragoza.es/sparql";
        $sc = new SparqlClient();
        $sc->setEndpointRead($endpoint);
        $q = "PREFIX dcterms: <http://purl.org/dc/terms/>
                PREFIX callejero: <http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/callejero#>
                
                SELECT DISTINCT ?uriCont ?id ?title
                WHERE { ?uriCont a callejero:Portal.
                  OPTIONAL{ ?uriCont dcterms:identifier ?id}.
                  OPTIONAL{ ?uriCont rdfs:label ?title}.
                }";

        $rows = $sc->query($q, 'rows');
        $err = $sc->getErrors();

        if ($err) {

            throw new Exception(print_r($err, true));
        }

        return $rows;
    }

}