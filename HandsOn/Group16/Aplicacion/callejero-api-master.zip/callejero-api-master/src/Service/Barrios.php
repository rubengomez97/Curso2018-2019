<?php
/**
 * Created by PhpStorm.
 * User: Jaime
 * Date: 02/12/2018
 * Time: 18:11
 */

namespace App\Service;

use BorderCloud\SPARQL\SparqlClient;
use Symfony\Component\Config\Definition\Exception\Exception;

class Barrios
{

    public function getBarrios()
    {

        //require_once ('../vendor/autoload.php');

        $endpoint = "http://datos.zaragoza.es/sparql";
        $sc = new SparqlClient();
        $sc->setEndpointRead($endpoint);
        $q = "PREFIX dcterms: <http://purl.org/dc/terms/>
                PREFIX territorio: <http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#>
                
                SELECT DISTINCT ?uriCont ?id ?title
                WHERE { ?uriCont a territorio:Barrio.
                  OPTIONAL{ ?uriCont dcterms:identifier ?id}.
                  OPTIONAL{ ?uriCont rdfs:label ?title}.
                }";

        $rows = $sc->query($q, 'rows');
        $err = $sc->getErrors();

        if ($err) {

            throw new Exception(print_r($err, true));
        }

        return $rows;
    }


    public static function getInfoBarrio($idBarrio){

        $endpoint = "http://datos.zaragoza.es/sparql";
        $sc = new SparqlClient();
        $sc->setEndpointRead($endpoint);

        $q = "PREFIX dcterms: <http://purl.org/dc/terms/>
                PREFIX callejero: <http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/callejero#>
                
                SELECT DISTINCT ?uriCont ?id ?title
                WHERE { ?uriCont a callejero:Via.
                    FILTER regex(?title, ".$idBarrio.", 'i' ). 
                  OPTIONAL{ ?uriCont dcterms:identifier ?id}.
                  OPTIONAL{ ?uriCont rdfs:label ?title}.
                }
                LIMIT 100";
        print_r($q);
        $rows = $sc->query($q, 'rows');

        if ($err = $sc->getErrors()) {

            throw new Exception(print_r($err, true));
        }

        return $rows;
    }

}