<?php
/**
 * Created by PhpStorm.
 * User: Jaime
 * Date: 10/12/2018
 * Time: 19:12
 */

namespace App\Service;

use BorderCloud\SPARQL\SparqlClient;


class Calles
{
    /**
     * @return array|bool
     */
    public function getCalles()
    {

        $endpoint = "http://datos.zaragoza.es/sparql";
        $sc = new SparqlClient();
        $sc->setEndpointRead($endpoint);
        $q = "PREFIX dcterms: <http://purl.org/dc/terms/>
                PREFIX callejero: <http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/callejero#>
                
                SELECT DISTINCT ?uriCont ?id ?title
                WHERE { ?uriCont a callejero:Via.
                  OPTIONAL{ ?uriCont dcterms:identifier ?id}.
                  OPTIONAL{ ?uriCont rdfs:label ?title}.
                }";

        $rows = $sc->query($q, 'rows');
        $err = $sc->getErrors();

        if ($err) {

            throw new Exception(print_r($err, true));
        }

        return $rows;
    }
}