import React from 'react'
import ReactDOM from 'react-dom'
import BootstrapTable from 'react-bootstrap-table-next'
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter'
import paginationFactory from 'react-bootstrap-table2-paginator'

var recargaTabla
var datos = [
    {
        url:"https://callejero.api.local/calles",
        name: "Calles"
    },
    {
        url:"https://callejero.api.local/barrios",
        name: "Barrios"
    },
    {
        url:"https://callejero.api.local/portales",
        name: "Portales"
    }

]

class Boton extends React.Component {
    handleClick (event) {
        event.preventDefault()
        //Fetch para esto necesitamos this.props.url
        window.fetch(this.props.url, {
            method: 'GET',
        })
        .then(res => res.json()) // Lo procesamos como un JSON.
        .then(
            (result) => { //  En caso de funcionar.
                //console.log("recargando la tabla: ",recargaTabla)
                recargaTabla(result)
            },
            (error) => { // En caso de error.
                this.setState({
                    error: error //  Creamos el error para procesarlo despues.
                })
            }
        )
    }

    render () {
        return <li className="nav-item active">
            <a id="ayuda" onClick={(event) => this.handleClick(event)} className="nav-link" href={""}><i className="fa fa-question-circle"></i> {this.props.name} </a>
        </li>
    }
}
class Navbar extends React.Component {

    render () {
        let botones = datos.map((item) => {
            return <Boton key={item.name} name={item.name} url={item.url}/>
        })
        return <ul className="navbar-nav">
            {botones}
        </ul>
    }
}
class Tabla extends React.Component {
    constructor (props) {
        super(props)
        //console.log("constructor")
        recargaTabla = this.recargaTabla.bind(this)
        this.state = {
            isLoaded: false,
            data: null
        }
    }
    recargaTabla (lista) {
        //console.log("vamos a actualizar la tabla")
        this.setState({
            isLoaded: true,
            data: lista['result']['rows']
        })
    }
    render () {
        let {isLoaded, data} = this.state
        //console.log("render: ", data)
        if (isLoaded) {
            return <BootstrapTable
                keyField='id'
                data={data}
                columns={columns}
                filter={filterFactory()}
                pagination={ paginationFactory(options)}
                condensed />
        } else {
            return ('Cargando')
        }
    }
}

const columns = [
    {
        dataField: 'title',
        text: 'Nombre',
        filter: textFilter(),
        sort: true
    },{
        dataField: 'uriCont',
        text: 'URI',
        filter: textFilter(),
        sort: true
    }
]
const options = {
    paginationSize: 4,
    pageStartIndex: 0,
    firstPageText: 'First',
    prePageText: 'Back',
    nextPageText: 'Next',
    lastPageText: 'Last',
    nextPageTitle: 'First page',
    prePageTitle: 'Pre page',
    firstPageTitle: 'Next page',
    lastPageTitle: 'Last page',
    showTotal: true,
    paginationTotalRenderer: customTotal,
    sizePerPageList: [{text: '10', value: 10}]
};
const customTotal = (from, to, size) => ( <span className="react-bootstrap-table-pagination-total"> Mostrando { from } to { to } of { size } resultados </span> );

ReactDOM.render(<Navbar/>, document.getElementById('react-navbar'))
ReactDOM.render(<Tabla/>, document.getElementById('react-tabla'))