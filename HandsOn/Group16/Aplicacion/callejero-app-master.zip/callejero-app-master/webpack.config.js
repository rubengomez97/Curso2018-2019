const path = require('path')
const HWP = require('html-webpack-plugin')

module.exports = {
    entry: path.join(__dirname, '/assets/index.jsx'),
    output: {
        filename: 'index.js',
        path: path.join(__dirname, '/public/')
    },
    module: {
        rules: [
            {
                test: /\.jsx$/,
                exclude: /node_modules/,
                loader: 'babel-loader'
            },
            {
                test: /\.css$/,
                use: ['css-loader', 'style-loader'],
            },
            // ...
        ],
        //...
    },
    plugins: [
        new HWP(
            {template: path.join(__dirname, '/public/index.html')}
        )
    ]
}